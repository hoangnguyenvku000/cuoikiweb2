var list_products = [{
}, {
    "name": "Áo tấc đỏ",
    "company": "Việt phục",
    "img": "img/products/ao_tac_do.jpg",
    "price": "3.190.000",
    "star": 5,
    "rateCount": 7,
    "promo": {
        "name": "giamgia",
        "value": "250.000"
    },
    "detail": {
        "screen": "IPS LCD, 6.26', Full HD+",
        "os": "Android 8.1 (Oreo)",
        "camara": "12 MP và 5 MP (2 camera)",
        "camaraFront": "24 MP",
        "cpu": "Qualcomm Snapdragon 660 8 nhân",
        "ram": "4 GB",
        "rom": "64 GB",
        "microUSB": "MicroSD, hỗ trợ tối đa 512 GB",
        "battery": "3300 mAh, có sạc nhanh"
    },
    "masp": "Xia0"
}, {
    "name": "Áo tấc xanh",
    "company": "Việt phục",
    "img": "img/products/ao_tac_xanh.jpg",
    "price": "4.790.000",
    "star": 5,
    "rateCount": 7,
    "promo": {
        "name": "giamgia",
        "value": "250.000"
    },
}]